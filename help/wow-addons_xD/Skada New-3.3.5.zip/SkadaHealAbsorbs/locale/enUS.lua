local L = LibStub("AceLocale-3.0"):NewLocale("SkadaHealAbsorbs", "enUS", true)

if L then
	L["Healing and Absorbs"] = true
	L["Healing and Absorbs spell list"] = true
	L["Healed and Absorbed players"] = true
	L["'s Healing"] = true
	L["'s Healing & Absorbs"] = true
	L["Average hit:"] = true
	L["Maximum hit:"] = true
	L["Minimum hit:"] = true
	L["Absorbs"] = true
	L["Healed players"] = true
	L["Healed by"] = true
	L["Spell details"] = true
	L["Healing spell list"] = true
	L["HPS"] = true
	L["Critical"] = true
	L["Overhealing"] = true
end