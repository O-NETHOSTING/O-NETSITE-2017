--[[
	Bagnon_Tooltips Localization
		German
--]]

if ( GetLocale() == "deDE" ) then

BAGNON_NUM_BAGS = 'Taschen: %d'
BAGNON_NUM_BANK = 'Bank: %d'
BAGNON_EQUIPPED = 'Angelegt'

end